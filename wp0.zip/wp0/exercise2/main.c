// (C) Filip Bystedt, Viggo Vahnström, group: 28 (2026)
// Work package 0
// Exercise 1
// Submission code: 28FBVVWP0 (provided by your TA-s)

#include <stdio.h>                                              // package for input-output functions
                                        
int main (int argc, char *argv[]) {                             // argc = argument count, and argv is the array of strings
    printf("Hello World! – I'm %s!\n", argv[1]);                // printing
    return 0;                                                   // 0 to indicate successful 
}