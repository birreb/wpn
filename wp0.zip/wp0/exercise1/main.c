// (C) Filip Bystedt, Viggo Vahnström, group: 28 (2026)
// Work package 0
// Exercise 1
// Submission code: 28FBVVWP0 (provided by your TA-s)

#include <stdio.h>

// Main function in the program, no program arguments supported
int main (void) 
{
    // Print a string to the console
    printf("%s", "Hello World!\n"); // Note: double quotes
}